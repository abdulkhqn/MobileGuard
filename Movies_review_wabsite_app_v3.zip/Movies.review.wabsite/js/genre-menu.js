(function () {
  "use strict";

  // Stylish "Explore Genres" panel.
  // Opens when the user taps the three-line menu and then "Genres"
  // (or clicks "Genres" in the top navigation on desktop).

  const COLORS = {
    "action": "#ff7a59",
    "sci-fi": "#5ac8fa",
    "drama": "#c792ea",
    "crime": "#ffd166",
    "adventure": "#4ade80",
    "history": "#e0a96d",
    "comedy": "#ffe066",
    "horror": "#ff5d73"
  };
  const FALLBACK = ["#496BBF", "#5ac8fa", "#ff7a59", "#c792ea", "#ffd166", "#4ade80"];

  let overlay = null;
  let lastFocus = null;
  let closeTimer = null;

  function esc(value) {
    const map = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
    return String(value == null ? "" : value).replace(/[&<>"']/g, function (c) { return map[c]; });
  }

  function genreList() {
    return Array.isArray(window.GENRE_DATA) ? window.GENRE_DATA : [];
  }

  function movieList() {
    try {
      const list = window.CineStorage ? window.CineStorage.getMovies() : (window.MOVIE_DATA || []);
      return Array.isArray(list) ? list : [];
    } catch (error) {
      return window.MOVIE_DATA || [];
    }
  }

  function countFor(name, movies) {
    const wanted = String(name).toLowerCase();
    return movies.filter(function (movie) {
      const genres = Array.isArray(movie && movie.genres) ? movie.genres : [];
      return genres.some(function (g) { return String(g).toLowerCase() === wanted; });
    }).length;
  }

  function cardsHTML() {
    const movies = movieList();

    return genreList().map(function (genre, index) {
      const key = String(genre.name || "").toLowerCase();
      const color = COLORS[key] || FALLBACK[index % FALLBACK.length];
      const count = countFor(genre.name, movies);

      return '<a class="gs-card" style="--g:' + color + ';--i:' + index + '" ' +
        'href="./search.html?genre=' + encodeURIComponent(genre.name) + '">' +
        '<span class="gs-count">' + count + (count === 1 ? " movie" : " movies") + '</span>' +
        '<span class="gs-icon"><i class="fa-solid ' + esc(genre.icon) + '"></i></span>' +
        '<span class="gs-text"><strong>' + esc(genre.name) + '</strong>' +
        '<small>' + esc(genre.description) + '</small></span>' +
        '<i class="fa-solid fa-arrow-right gs-arrow" aria-hidden="true"></i>' +
        '</a>';
    }).join("");
  }

  // Third option in the panel: ask for a movie that is not in the library yet
  function requestCardHTML() {
    return '<button type="button" class="gs-card gs-request" data-open-request style="--g:#7F9BE0;--i:' + genreList().length + '">' +
      '<span class="gs-icon"><i class="fa-solid fa-circle-plus"></i></span>' +
      '<span class="gs-text"><strong>Request a movie</strong>' +
      '<small>Movie not found? Send us the name</small></span>' +
      '<i class="fa-solid fa-arrow-right gs-arrow" aria-hidden="true"></i>' +
      '</button>';
  }

  // ---------- request sheet ----------
  let reqOverlay = null;
  function buildRequest() {
    if (reqOverlay) return;
    reqOverlay = document.createElement("div");
    reqOverlay.className = "req-overlay";
    reqOverlay.hidden = true;
    reqOverlay.innerHTML =
      '<div class="req-sheet" role="dialog" aria-modal="true" aria-labelledby="reqTitle">' +
        '<button type="button" class="gs-close req-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>' +
        '<div class="req-form-view">' +
          '<span class="section-kicker">MOVIE REQUEST</span>' +
          '<h2 id="reqTitle">Movie <span class="accent">request</span></h2>' +
          '<p class="req-sub">Can\'t find a movie in the library? Type its name and we will add it.</p>' +
          '<form class="req-form" autocomplete="off">' +
            '<input type="text" id="reqName" maxlength="100" placeholder="e.g. Dhoom 3, Interstellar" required>' +
            '<p class="req-error" id="reqError"></p>' +
            '<button type="submit" class="req-submit"><i class="fa-solid fa-paper-plane"></i> Submit request</button>' +
          '</form>' +
        '</div>' +
        '<div class="req-thanks-view" hidden>' +
          '<div class="req-check"><svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="28"/><path d="M19 33 l9 9 l18 -20"/></svg></div>' +
          '<h2 class="req-thanks-en">Thank you!</h2>' +
          '<p class="req-thanks-en-sub">Your request has been received. We will add it soon.</p>' +
          '' +
          '' +
          '<button type="button" class="primary-btn req-done">Done</button>' +
          '<div class="req-sparks" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(reqOverlay);

    reqOverlay.addEventListener("click", function (e) {
      if (e.target === reqOverlay || e.target.closest(".req-close") || e.target.closest(".req-done")) closeRequest();
    });

    reqOverlay.querySelector(".req-form").addEventListener("submit", async function (e) {
      e.preventDefault();
      const input = document.getElementById("reqName");
      const err = document.getElementById("reqError");
      const btn = reqOverlay.querySelector(".req-submit");
      err.textContent = "";
      if (!input.value.trim()) { err.textContent = "Please type a movie name."; return; }
      btn.disabled = true;
      try {
        await window.CineRequests.submit(input.value);
        input.value = "";            // name is not kept on screen
        showThanks();
      } catch (error) {
        err.textContent = "Could not send the request. Check your internet and try again.";
      } finally {
        btn.disabled = false;
      }
    });
  }

  function showThanks() {
    const form = reqOverlay.querySelector(".req-form-view");
    const thanks = reqOverlay.querySelector(".req-thanks-view");
    form.hidden = true;
    thanks.hidden = false;
    thanks.classList.remove("play");
    void thanks.offsetWidth;
    thanks.classList.add("play");
  }

  function openRequest() {
    buildRequest();
    const form = reqOverlay.querySelector(".req-form-view");
    const thanks = reqOverlay.querySelector(".req-thanks-view");
    form.hidden = false;
    thanks.hidden = true;
    reqOverlay.hidden = false;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(function () {
      reqOverlay.classList.add("open");
      setTimeout(function () { var i = document.getElementById("reqName"); i && i.focus(); }, 250);
    });
  }

  window.CineOpenRequest = function (prefill) {
    openRequest();
    setTimeout(function () {
      const i = document.getElementById("reqName");
      if (i && prefill) i.value = String(prefill).slice(0, 100);
    }, 60);
  };

  function closeRequest() {
    if (!reqOverlay || reqOverlay.hidden) return;
    reqOverlay.classList.remove("open");
    document.body.style.overflow = "";
    setTimeout(function () { reqOverlay.hidden = true; }, 260);
  }

  document.addEventListener("click", function (e) {
    if (e.target.closest && e.target.closest("[data-open-request]")) {
      e.preventDefault();
      closeMobileNav();
      if (overlay && !overlay.hidden) closePanel();
      setTimeout(openRequest, overlay && !overlay.hidden ? 280 : 0);
    }
  });

  function build() {
    if (overlay) return;

    overlay = document.createElement("div");
    overlay.className = "genre-sheet-overlay";
    overlay.hidden = true;
    overlay.innerHTML =
      '<div class="genre-sheet" role="dialog" aria-modal="true" aria-labelledby="genreSheetTitle">' +
        '<button type="button" class="gs-close" aria-label="Close genres"><i class="fa-solid fa-xmark"></i></button>' +
        '<div class="gs-head">' +
          '<div>' +
            '<span class="section-kicker">FIND YOUR NEXT FILM</span>' +
            '<h2 id="genreSheetTitle">Explore <span class="accent">Genres</span></h2>' +
          '</div>' +
          '<a class="gs-all" href="./search.html">All movies <i class="fa-solid fa-arrow-right"></i></a>' +
        '</div>' +
        '<div class="gs-grid"></div>' +
      '</div>';

    document.body.appendChild(overlay);

    overlay.addEventListener("click", function (event) {
      if (event.target === overlay || event.target.closest(".gs-close")) {
        closePanel();
      }
    });
  }

  function closeMobileNav() {
    const nav = document.getElementById("mainNav");
    const button = document.getElementById("menuToggle");

    if (nav) nav.classList.remove("mobile-open");

    if (button) {
      button.setAttribute("aria-expanded", "false");
      button.innerHTML = '<i class="fa-solid fa-bars"></i>';
    }
  }

  function openPanel() {
    build();
    window.clearTimeout(closeTimer);

    lastFocus = document.activeElement;
    overlay.querySelector(".gs-grid").innerHTML = cardsHTML();
    overlay.hidden = false;
    document.body.style.overflow = "hidden";
    closeMobileNav();

    window.requestAnimationFrame(function () {
      overlay.classList.add("open");
      const close = overlay.querySelector(".gs-close");
      if (close) close.focus();
    });
  }

  function closePanel() {
    if (!overlay || overlay.hidden) return;

    overlay.classList.remove("open");
    document.body.style.overflow = "";

    closeTimer = window.setTimeout(function () {
      overlay.hidden = true;
    }, 260);

    if (lastFocus && typeof lastFocus.focus === "function") {
      lastFocus.focus();
    }
  }

  document.addEventListener("click", function (event) {
    const trigger = event.target.closest("[data-open-genres]");

    if (!trigger) return;

    event.preventDefault();
    openPanel();
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && overlay && !overlay.hidden) {
      closePanel();
    }
  });
})();
