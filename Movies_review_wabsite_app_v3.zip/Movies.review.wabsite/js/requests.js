(function () {
  "use strict";

  // Movie requests + notifications for the public site.
  // Each browser gets a random key (no login). Requests and notifications use that key.
  const cfg = window.CINE_SUPABASE || {};
  const BASE = (cfg.url || "").replace(/\/$/, "");
  const ANON = cfg.anonKey || "";
  const KEY_NAME = "cinereview_user_key";
  const SEEN_NAME = "cinereview_seen_notifs";

  function uuid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return "k-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 12);
  }

  function userKey() {
    let k = null;
    try { k = localStorage.getItem(KEY_NAME); } catch (e) {}
    if (!k) {
      k = uuid();
      try { localStorage.setItem(KEY_NAME, k); } catch (e) {}
    }
    return k;
  }

  function seen() {
    try { return JSON.parse(localStorage.getItem(SEEN_NAME) || "[]"); } catch (e) { return []; }
  }

  function markSeen(ids) {
    const set = new Set(seen());
    ids.forEach(function (id) { set.add(String(id)); });
    try { localStorage.setItem(SEEN_NAME, JSON.stringify(Array.from(set).slice(-200))); } catch (e) {}
  }

  async function submit(name) {
    const clean = String(name || "").trim().slice(0, 100);
    if (!clean) throw new Error("EMPTY");
    const r = await fetch(BASE + "/rest/v1/movie_requests", {
      method: "POST",
      headers: {
        apikey: ANON,
        Authorization: "Bearer " + ANON,
        "Content-Type": "application/json",
        Prefer: "return=minimal"
      },
      body: JSON.stringify({ movie_name: clean, user_key: userKey() })
    });
    if (!r.ok) throw new Error("SUBMIT_FAILED");
    return true;
  }

  async function notifications() {
    const r = await fetch(
      BASE + "/rest/v1/notifications?select=id,title,message,movie_title,created_at&user_key=eq." + encodeURIComponent(userKey()) + "&order=created_at.desc&limit=50",
      { headers: { apikey: ANON, Authorization: "Bearer " + ANON } }
    );
    if (!r.ok) throw new Error("FETCH_FAILED");
    return r.json();
  }

  window.CineRequests = {
    userKey: userKey,
    submit: submit,
    notifications: notifications,
    seen: seen,
    markSeen: markSeen
  };
})();
