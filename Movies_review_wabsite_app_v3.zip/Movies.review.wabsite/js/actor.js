(function () {
  "use strict";

  // Actor sheet: photo, bio and every movie/series the actor worked on (with posters).
  const API = "https://api.themoviedb.org/3";
  const IMG = "https://image.tmdb.org/t/p/";
  const KEY = (window.CINE_TMDB && window.CINE_TMDB.apiKey) || "";
  const cache = {};

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  async function tmdb(path, params) {
    const url = new URL(API + path);
    url.searchParams.set("api_key", KEY);
    url.searchParams.set("language", "en-US");
    Object.keys(params || {}).forEach(function (k) { url.searchParams.set(k, params[k]); });
    const r = await fetch(url.toString());
    if (!r.ok) throw new Error("TMDB error " + r.status);
    return r.json();
  }

  function libraryIndex() {
    const movies = window.CineStorage ? window.CineStorage.getMovies() : [];
    const byKey = new Map();
    const byTitleYear = new Map();
    movies.forEach(function (m) {
      if (m.tmdbId) byKey.set(String(m.tmdbId), m);
      byTitleYear.set(String(m.title).toLowerCase() + "|" + String(m.year), m);
    });
    return { byKey: byKey, byTitleYear: byTitleYear };
  }

  function findInLibrary(idx, credit) {
    const type = credit.media_type === "tv" ? "tv" : "movie";
    const title = credit.media_type === "tv" ? credit.name : credit.title;
    const date = credit.media_type === "tv" ? credit.first_air_date : credit.release_date;
    const year = date ? date.slice(0, 4) : "";
    return idx.byKey.get(type + ":" + credit.id) ||
      idx.byTitleYear.get(String(title || "").toLowerCase() + "|" + year) || null;
  }

  function sheetEl() {
    let el = document.getElementById("actorSheet");
    if (el) return el;
    el = document.createElement("div");
    el.id = "actorSheet";
    el.className = "actor-overlay";
    el.hidden = true;
    el.innerHTML =
      '<div class="actor-sheet" role="dialog" aria-modal="true" aria-labelledby="actorName">' +
        '<button type="button" class="actor-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>' +
        '<div class="actor-body"></div>' +
      '</div>';
    document.body.appendChild(el);
    el.addEventListener("click", function (e) {
      if (e.target === el || e.target.closest(".actor-close")) close();
    });
    el.addEventListener("click", function (e) {
      const more = e.target.closest("[data-bio-toggle]");
      if (more) {
        const bio = el.querySelector(".actor-bio");
        bio.classList.toggle("is-open");
        more.textContent = bio.classList.contains("is-open") ? "Show less" : "Read more";
      }
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    return el;
  }

  function close() {
    const el = document.getElementById("actorSheet");
    if (!el || el.hidden) return;
    el.classList.remove("open");
    document.body.style.overflow = "";
    setTimeout(function () { el.hidden = true; }, 260);
  }

  function renderLoading(el, name) {
    el.querySelector(".actor-body").innerHTML =
      '<div class="actor-loading"><span></span><span></span><span></span></div>' +
      '<p class="actor-loading-text">Loading ' + esc(name || "actor") + '...</p>';
  }

  function renderError(el, msg) {
    el.querySelector(".actor-body").innerHTML =
      '<div class="empty-state"><i class="fa-solid fa-circle-exclamation"></i><h3>Could not load actor</h3><p>' + esc(msg) + '</p></div>';
  }

  function creditCard(credit, idx, i) {
    const isTv = credit.media_type === "tv";
    const title = isTv ? credit.name : credit.title;
    const date = isTv ? credit.first_air_date : credit.release_date;
    const year = date ? date.slice(0, 4) : "";
    const poster = credit.poster_path ? IMG + "w342" + credit.poster_path : "";
    const local = findInLibrary(idx, credit);
    const role = credit.character ? '<small class="actor-role">as ' + esc(credit.character) + '</small>' : "";
    const inner =
      '<span class="actor-poster">' + (poster ? '<img src="' + esc(poster) + '" alt="" loading="lazy">' : '<i class="fa-solid fa-film"></i>') + '</span>' +
      '<span class="actor-film-text"><strong>' + esc(title || "Untitled") + '</strong>' +
      '<small>' + esc(year || "-") + ' · ' + (isTv ? "Series" : "Movie") + '</small>' + role;
    if (local) {
      return '<a class="actor-film" href="./movie.html?id=' + encodeURIComponent(local.id) + '" style="--i:' + i + '">' + inner + '</span></a>';
    }
    // Not in the library: open the movie on TMDB in a new tab
    const tmdbHref = "https://www.themoviedb.org/" + (isTv ? "tv" : "movie") + "/" + credit.id;
    return '<a class="actor-film" href="' + esc(tmdbHref) + '" target="_blank" rel="noopener" style="--i:' + i + '">' + inner +
      '<span class="actor-badge">Not in library</span></span></a>';
  }

  async function open(personId, name) {
    const id = String(personId || "").replace(/\D/g, "");
    if (!id) return;
    if (!KEY) return;
    const el = sheetEl();
    renderLoading(el, name);
    el.hidden = false;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(function () { el.classList.add("open"); });

    try {
      if (!cache[id]) cache[id] = await tmdb("/person/" + id, { append_to_response: "combined_credits" });
      const p = cache[id];
      const idx = libraryIndex();

      const seen = new Set();
      const credits = ((p.combined_credits && p.combined_credits.cast) || [])
        .filter(function (c) { return c.media_type === "movie" || c.media_type === "tv"; })
        .filter(function (c) {
          const key = c.media_type + ":" + c.id;
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        })
        .sort(function (a, b) {
          const da = (a.release_date || a.first_air_date || "0");
          const db = (b.release_date || b.first_air_date || "0");
          return db.localeCompare(da);
        })
        .slice(0, 80);

      const bio = p.biography || "No biography available.";
      const meta = [p.birthday, p.place_of_birth].filter(Boolean).map(esc).join(" · ");
      const photo = p.profile_path ? IMG + "w342" + p.profile_path : "";

      el.querySelector(".actor-body").innerHTML =
        '<div class="actor-head">' +
          '<div class="actor-photo">' + (photo ? '<img src="' + esc(photo) + '" alt="' + esc(p.name) + '">' : '<span>' + esc((p.name || "?")[0]) + '</span>') + '</div>' +
          '<div class="actor-id"><span class="section-kicker">ACTOR</span>' +
            '<h2 id="actorName">' + esc(p.name || name || "") + '</h2>' +
            (meta ? '<p class="actor-meta">' + meta + '</p>' : '') +
          '</div>' +
        '</div>' +
        '<div class="actor-bio-wrap"><p class="actor-bio">' + esc(bio) + '</p>' +
          (bio.length > 180 ? '<button type="button" class="actor-more" data-bio-toggle>Read more</button>' : '') + '</div>' +
        '<div class="actor-films-head"><h3>Movies & series</h3><span>' + credits.length + '</span></div>' +
        '<div class="actor-films">' + (credits.length ? credits.map(function (c, i) { return creditCard(c, idx, i); }).join("") : '<p class="actor-none">No movies or series found.</p>') + '</div>';

      el.querySelector(".actor-body").scrollTop = 0;
    } catch (error) {
      renderError(el, error.message || "Please check your internet and try again.");
    }
  }

  window.CineActor = { open: open, close: close };
})();
