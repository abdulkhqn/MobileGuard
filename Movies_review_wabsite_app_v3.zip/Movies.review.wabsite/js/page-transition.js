(function () {
  "use strict";

  // Animated hand-off from a movie card to the details page.
  // The clicked poster grows, the page fades out, then movie.html opens.

  const EXIT_MS = 420;

  document.addEventListener("click", function (event) {
    if (event.defaultPrevented || event.button !== 0) return;
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

    const link = event.target.closest('a[href*="movie.html?id="]');
    if (!link) return;

    // Only animate links to a movie page on this site.
    const url = new URL(link.href, window.location.href);
    if (url.origin !== window.location.origin) return;
    if (document.body.classList.contains("page-exit")) { event.preventDefault(); return; }

    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    event.preventDefault();
    const card = link.closest(".movie-card");
    if (card) {
      const poster = card.querySelector(".movie-poster-wrap") || card;
      poster.classList.add("is-opening");
    }
    document.body.classList.add("page-exit");

    window.setTimeout(function () {
      window.location.href = url.href;
    }, EXIT_MS);
  });

  // Fade the page back in if the browser restores it from cache.
  window.addEventListener("pageshow", function (event) {
    if (event.persisted) document.body.classList.remove("page-exit");
  });
})();
