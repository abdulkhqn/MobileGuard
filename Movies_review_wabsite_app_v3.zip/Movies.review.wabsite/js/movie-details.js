(function () {
  "use strict";
  const U = window.CineUtils;
  const $ = id => document.getElementById(id);
  const params = new URLSearchParams(location.search);
  let movieId = params.get("id");
  const COMMENTS_KEY = "cinereview_comments_v1";
  const RATINGS_KEY = "cinereview_user_ratings_v1";
  let currentMovie = null;
  let selectedRating = 0;

  function esc(v) { return U.escapeHTML(v == null ? "" : v); }
  function listText(v) { return Array.isArray(v) ? v.join(", ") : String(v || ""); }
  function castList(v) { return window.CineStorage.normalizeCast(v); }
  function verdictFor(r) {
    if(!Number.isFinite(r)) return "Not rated yet";
    if(r>=9) return "Masterpiece"; if(r>=8) return "Excellent"; if(r>=7) return "Great"; if(r>=6) return "Good"; return "Average";
  }
  function castCards(v){
    const list=window.CineStorage.normalizeCast(v);
    if(!list.length) return `<div class="cast-empty-note">Not specified</div>`;
    return list.map(c=>{
      const photo=U.getPosterURL(c.photo);
      const initials=c.name.split(/\s+/).slice(0,2).map(w=>w[0]||"").join("").toUpperCase();
      return `<figure class="cast-card${c.id?" is-clickable":""}" data-person-id="${c.id||""}" data-person-name="${esc(c.name)}"><div class="cast-photo">${photo?`<img src="${esc(photo)}" alt="${esc(c.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><span class="cast-initials" style="display:none">${esc(initials)}</span>`:`<span class="cast-initials">${esc(initials)}</span>`}</div><figcaption>${esc(c.name)}</figcaption></figure>`;
    }).join("");
  }
  function seasonsHTML(movie){
    const list=window.CineStorage.normalizeSeasons(movie.seasons);
    if(!list.length) return "";
    const items=list.map((se,i)=>{
      const eps=Array.from({length:se.episodes},(_,e)=>`<span class="ep-chip">E${e+1}</span>`).join("");
      return `<div class="season-item" style="--si:${i}"><button type="button" class="season-card" data-season-toggle="${i}" aria-expanded="false" aria-controls="season-panel-${i}">`+
        `<span class="season-num">S${se.number}</span><span class="season-text"><strong>Season ${se.number}</strong><small>${se.episodes} episodes</small></span>`+
        `<i class="fa-solid fa-chevron-down season-arrow" aria-hidden="true"></i></button>`+
        `<div class="season-panel" id="season-panel-${i}" hidden><div class="season-panel-inner"><p class="season-panel-title">Season ${se.number} · <b>${se.episodes}</b> episodes</p><div class="ep-grid">${eps}</div></div></div></div>`;
    }).join("");
    return `<div class="seasons-block"><div class="cast-slider-head"><h3><i class="fa-solid fa-layer-group"></i> Seasons</h3><span class="seasons-total">${list.length} season${list.length===1?"":"s"}</span></div><div class="season-list">${items}</div></div>`;
  }
  function safeTrailerURL(v) { const s=String(v||"").trim(); return /^https?:\/\//i.test(s) ? s : ""; }
  function readStore(key) {
    try { const x=JSON.parse(localStorage.getItem(key)||"{}"); return x && typeof x==="object" ? x : {}; }
    catch(e) { return {}; }
  }
  function writeStore(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch(e) { U.showToast("Could not save. Browser storage may be unavailable.", "error"); return false; }
  }
  function commentsForMovie() {
    const all=readStore(COMMENTS_KEY);
    return Array.isArray(all[String(currentMovie.id)]) ? all[String(currentMovie.id)] : [];
  }
  function saveComments(list) {
    const all=readStore(COMMENTS_KEY); all[String(currentMovie.id)]=list; return writeStore(COMMENTS_KEY,all);
  }
  function renderNotFound() {
    document.title="Movie not found | CineReview";
    $("movieDetails").innerHTML=`<div class="empty-state detail-empty"><i class="fa-solid fa-film"></i><h3>Movie not found</h3><p>This movie may have been removed or the link is incorrect.</p><a href="./index.html" class="primary-btn detail-back">Back to Home</a></div>`;
  }
  function renderSimilar(movie) {
    const section=$("similarSection"), grid=$("similarGrid");
    const gs=Array.isArray(movie.genres)?movie.genres:[];
    const similar=U.getMovies().filter(m=>String(m.id)!==String(movie.id)&&(Array.isArray(m.genres)?m.genres:[]).some(g=>gs.includes(g))).slice(0,5);
    if(similar.length){section.hidden=false;grid.innerHTML=similar.map(U.createMovieCard).join("");}
  }
  function commentHTML(c, index) {
    const liked=Array.isArray(c.likedBy)&&c.likedBy.includes("local-user");
    const replies=Array.isArray(c.replies)?c.replies:[];
    return `<article class="cr-comment" data-comment-index="${index}">
      <div class="cr-comment-top"><strong>${esc(c.name||"Viewer")}</strong><time>${esc(c.date||"")}</time></div>
      <p class="cr-comment-text">${esc(c.text||"")}</p>
      <div class="cr-comment-actions">
        <button type="button" data-comment-action="like" data-index="${index}" class="${liked?"is-liked":""}"><i class="fa-${liked?"solid":"regular"} fa-thumbs-up"></i> Like <span>${(Array.isArray(c.likedBy)?c.likedBy.length:0)}</span></button>
        <button type="button" data-comment-action="reply" data-index="${index}"><i class="fa-solid fa-reply"></i> Reply</button>
        <button type="button" class="cr-del-btn" data-comment-action="delete" data-index="${index}"><i class="fa-solid fa-trash-can"></i> Delete</button>
      </div>
      <form class="cr-reply-form" data-reply-form="${index}" hidden>
        <input name="replyName" maxlength="40" placeholder="Your name (optional)" aria-label="Your name">
        <textarea name="replyText" maxlength="500" required placeholder="Write a reply..." aria-label="Write a reply"></textarea>
        <button class="primary-btn" type="submit">Post reply</button>
      </form>
      ${replies.length?`<div class="cr-replies">${replies.map(r=>`<div class="cr-reply"><strong>${esc(r.name||"Viewer")}</strong><time>${esc(r.date||"")}</time><p>${esc(r.text||"")}</p></div>`).join("")}</div>`:""}
    </article>`;
  }
  function renderCommunity() {
    const host=$("movieCommunity"); if(!host) return;
    if(window.__cineUpcoming){
      host.innerHTML='<div class="upcoming-note"><i class="fa-regular fa-clock"></i><h3>Ratings & comments open after release</h3><p>This movie has not been released yet. Ratings and comments open after release.</p></div>';
      return;
    }
    const comments=commentsForMovie();
    const ratings=readStore(RATINGS_KEY);
    const own=ratings[String(currentMovie.id)] || 0;
    selectedRating=Number(own)||0;
    const avg=comments.length ? comments.reduce((s,c)=>s+(Array.isArray(c.likedBy)?c.likedBy.length:0),0) : 0;
    host.innerHTML=`<section class="cr-community">
      <div class="cr-section-heading"><span class="section-kicker">COMMUNITY</span><h2>Ratings & <span class="accent">Comments</span></h2><p>Share your rating, discuss the movie, and reply to other viewers.</p></div>
      <form class="cr-comment-form" id="crCommentForm"><h3>Write a comment</h3>
        <label>Name <input name="commentName" maxlength="40" placeholder="Your name (optional)"></label>
        <label>Comment <textarea name="commentText" maxlength="1000" required placeholder="What did you think about this movie?"></textarea></label>
        <button class="primary-btn" type="submit">Post comment</button>
      </form>
      <div class="cr-comments-heading"><h3>Viewer comments</h3><span>${comments.length} comment${comments.length===1?"":"s"}</span></div>
      <div id="crCommentsList">${comments.length?comments.map(commentHTML).join(""):`<p class="cr-no-comments">No comments yet. Be the first to comment.</p>`}</div>
      <p class="cr-local-note">Comments, likes, replies, and personal ratings are stored only in this browser. They are not shared across devices.</p>
    </section>`;
    $("crCommentForm").addEventListener("submit",e=>{
      e.preventDefault(); const f=e.currentTarget, text=f.elements.commentText.value.trim();
      if(!text) return;
      const list=commentsForMovie();
      list.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,6),name:f.elements.commentName.value.trim()||"Viewer",text,date:new Date().toLocaleString(),likedBy:[],replies:[]});
      if(saveComments(list)){renderCommunity();U.showToast("Comment posted.");}
    });
    if(!host._crBound){
      host._crBound=true;
    host.addEventListener("click",function handler(e){
      const b=e.target.closest("[data-comment-action]"); if(!b||!host.contains(b))return;
      const idx=Number(b.dataset.index);
      if(b.dataset.commentAction==="reply"){
        const form=host.querySelector(`[data-reply-form="${idx}"]`); if(form) form.hidden=!form.hidden;
      } else if(b.dataset.commentAction==="delete"){
        if(!b.dataset.armed){
          b.dataset.armed="1"; b.classList.add("is-armed");
          b.innerHTML='<i class="fa-solid fa-triangle-exclamation"></i> Tap again to delete';
          clearTimeout(b._armTimer);
          b._armTimer=setTimeout(function(){ delete b.dataset.armed; b.classList.remove("is-armed"); b.innerHTML='<i class="fa-solid fa-trash-can"></i> Delete'; },3000);
          return;
        }
        const list=commentsForMovie(); if(!list[idx])return;
        list.splice(idx,1);
        if(saveComments(list)){ renderCommunity(); U.showToast("Comment deleted."); }
      } else if(b.dataset.commentAction==="like"){
        const list=commentsForMovie(), c=list[idx]; if(!c)return;
        c.likedBy=Array.isArray(c.likedBy)?c.likedBy:[];
        const pos=c.likedBy.indexOf("local-user");
        if(pos>=0)c.likedBy.splice(pos,1); else c.likedBy.push("local-user");
        if(saveComments(list))renderCommunity();
      }
    });
    }
    host.querySelectorAll("[data-reply-form]").forEach(form=>form.addEventListener("submit",e=>{
      e.preventDefault(); const idx=Number(form.dataset.replyForm), text=form.elements.replyText.value.trim();
      if(!text)return;
      const list=commentsForMovie(), c=list[idx]; if(!c)return;
      c.replies=Array.isArray(c.replies)?c.replies:[];
      c.replies.push({name:form.elements.replyName.value.trim()||"Viewer",text,date:new Date().toLocaleString()});
      if(saveComments(list)){renderCommunity();U.showToast("Reply posted.");}
    }));
  }
  function addCommunityStyles(){
    if($("crCommunityStyles"))return;
    const s=document.createElement("style");s.id="crCommunityStyles";
    s.textContent=`
    .movie-swipe-nav{display:flex;align-items:center;justify-content:space-between;gap:12px;border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:13px 0;margin:4px 0 26px;color:var(--muted);font-size:13px}.movie-swipe-nav button{display:flex;align-items:center;gap:8px;border:1px solid var(--border);background:var(--surface-2);color:var(--text);border-radius:10px;padding:11px 13px;cursor:pointer}.movie-swipe-nav button:disabled{opacity:.35;cursor:not-allowed}.movie-swipe-nav small{color:var(--muted)}
    .cr-community{max-width:900px;margin:20px auto 55px;color:var(--text)}
    .cr-section-heading{margin-bottom:24px}.cr-section-heading h2{font:700 clamp(26px,4vw,36px) 'Outfit',Arial,sans-serif;margin:6px 0}.cr-section-heading>p,.cr-rate-box p{color:var(--muted);margin:6px 0}
    .cr-rate-box,.cr-comment-form{border:1px solid var(--border);background:var(--surface-2);border-radius:18px;padding:20px;margin:18px 0}
    .cr-rate-box h3,.cr-comment-form h3,.cr-comments-heading h3{margin:0 0 8px;font:700 20px 'Outfit',Arial,sans-serif}
    .cr-rating-controls{display:flex;flex-wrap:wrap;gap:7px;margin:16px 0 10px}
    .cr-star{min-width:40px;min-height:40px;border:1px solid var(--border);border-radius:10px;background:var(--surface);color:var(--text);font:600 14px inherit;cursor:pointer}
    .cr-star.active{background:var(--accent);color:#09090d;border-color:var(--accent)}
    .cr-your-rating{font-size:14px;color:var(--muted)}
    .cr-comment-form label{display:block;margin:14px 0;color:var(--muted);font-size:14px}
    .cr-comment-form input,.cr-comment-form textarea,.cr-reply-form input,.cr-reply-form textarea{display:block;width:100%;margin-top:7px;padding:12px 14px;border:1px solid var(--border);border-radius:10px;background:var(--surface);color:var(--text);font:inherit;box-sizing:border-box}
    .cr-comment-form textarea,.cr-reply-form textarea{min-height:100px;resize:vertical}
    .cr-comments-heading{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:28px 0 14px}.cr-comments-heading span,.cr-comment time,.cr-reply time{font-size:12px;color:var(--muted)}
    .cr-comment{padding:17px 0;border-bottom:1px solid var(--border)}.cr-comment-top{display:flex;align-items:center;gap:12px;flex-wrap:wrap}.cr-comment-text,.cr-reply p{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6;margin:10px 0}
    .cr-comment-actions{display:flex;gap:16px}.cr-comment-actions button{border:0;background:transparent;color:var(--muted);padding:7px 0;cursor:pointer;font:inherit}.cr-comment-actions button.is-liked{color:var(--accent)}
    .cr-reply-form{margin:12px 0 12px 16px;padding:14px;border-left:2px solid var(--accent)}.cr-replies{margin:12px 0 0 16px;padding-left:14px;border-left:2px solid var(--border)}.cr-reply{padding:10px 0}.cr-reply strong{margin-right:10px}.cr-no-comments,.cr-local-note{color:var(--muted);font-size:13px}.cr-local-note{margin-top:18px}
    @media(max-width:600px){.movie-swipe-nav{font-size:11px}.movie-swipe-nav button{padding:10px 8px}.movie-swipe-nav button span{max-width:64px}.cr-rate-box,.cr-comment-form{padding:15px}.cr-star{min-width:34px;min-height:38px}.cr-comments-heading{align-items:flex-start}}
    `;
    document.head.appendChild(s);
  }
  function render(movie) {
    window.__cineUpcoming=!!(window.CineSmart && window.CineSmart.isUpcoming(movie));
    const trailer=safeTrailerURL(movie.trailer), backdrop=U.getPosterURL(movie.backdrop), poster=U.getPosterURL(movie.poster);
    const rating=Number(movie.rating), ratingText=Number.isFinite(rating)?Math.max(0,Math.min(10,rating)).toFixed(1):"N/A";
    const genres=Array.isArray(movie.genres)?movie.genres:[], title=esc(movie.title);
    const allMovies=U.getMovies();
    const currentIndex=allMovies.findIndex(m=>String(m.id)===String(movie.id));
    const hasPrevious=currentIndex>0, hasNext=currentIndex>=0&&currentIndex<allMovies.length-1;
    document.title=movie.title+" | CineReview";
    $("movieDetails").innerHTML=`
      ${backdrop?`<div class="detail-backdrop"><img src="${esc(backdrop)}" alt="" onerror="this.parentNode.hidden=true"></div>`:""}
      <div class="detail-layout"><div class="detail-poster-col"><div class="movie-poster-wrap detail-poster">
      ${poster?`<img class="movie-poster" src="${esc(poster)}" data-fallback="${esc(movie.backdrop || '')}" alt="${title} poster" onerror="if(this.dataset.fallback && this.src!==this.dataset.fallback){this.src=this.dataset.fallback;this.dataset.fallback='';}else{this.style.display='none';var p=this.nextElementSibling;if(p)p.style.display='flex';}"><div class="movie-poster-placeholder" style="display:none"><i class="fa-solid fa-film"></i><span>${title}</span></div>`:`<div class="movie-poster-placeholder"><i class="fa-solid fa-film"></i><span>${title}</span></div>`}
      <span class="rating-badge"><i class="fa-solid fa-star"></i> ${ratingText}</span>${U.watchlistButtonHTML(movie.id,U.isSaved(movie.id))}</div></div>
      <div class="detail-info"><span class="section-kicker">${esc(movie.language||"English")} · MOVIE PROFILE</span><h1 class="detail-title">${title}</h1>
      <div class="movie-meta detail-meta"><span class="meta-chip"><i class="fa-regular fa-calendar"></i> ${esc(movie.year||"—")}</span><span class="meta-chip"><i class="fa-solid fa-language"></i> ${esc(movie.language||"English")}</span></div>
      <div class="detail-tags">${genres.map(g=>`<span class="movie-genre">${esc(g)}</span>`).join("")}</div>
      ${window.__cineUpcoming ? `<div class="upcoming-box"><i class="fa-regular fa-calendar-plus"></i><div><span class="section-kicker">COMING SOON</span><strong>Releases on ${esc(window.CineSmart.releaseLabel(movie))}</strong><small>Rating will show after release.</small></div></div>` : `<div class="imdb-card">
        <div class="imdb-ring" style="--p:${Number.isFinite(rating)?Math.max(0,Math.min(10,rating))*10:0}"><div class="imdb-ring-inner"><b>${esc(ratingText)}</b><small>/ 10</small></div></div>
        <div class="imdb-body"><span class="imdb-logo">IMDb</span><strong class="imdb-verdict">${esc(verdictFor(rating))}</strong>
          <div class="imdb-bar"><i style="width:${Number.isFinite(rating)?Math.max(0,Math.min(10,rating))*10:0}%"></i></div>
          <span class="imdb-note"><i class="fa-solid fa-star"></i> IMDb rating out of 10</span></div>
      </div>`}
      <div class="detail-block synopsis-card"><span class="section-kicker">THE STORY</span><h3><i class="fa-solid fa-align-left"></i> Description</h3><p>${esc(movie.synopsis||"No description added yet.")}</p></div>
      ${seasonsHTML(movie)}<div class="crew-grid">
        <div class="detail-block crew-card"><h3><i class="fa-solid fa-clapperboard"></i> Director</h3><p class="crew-name">${esc(movie.director||"Not specified")}</p></div>
        <div class="cast-slider-block"><div class="cast-slider-head"><h3><i class="fa-solid fa-users"></i> Actors / Cast</h3><div class="cast-nav"><button type="button" data-cast-dir="-1" aria-label="Previous actors"><i class="fa-solid fa-chevron-left"></i></button><button type="button" data-cast-dir="1" aria-label="Next actors"><i class="fa-solid fa-chevron-right"></i></button></div></div><div class="cast-slider" id="castSlider">${castCards(movie.cast)}</div></div>
      </div>
      <div class="detail-actions">${trailer?`<button type="button" class="primary-btn" data-trailer-play="${esc(trailer)}"><i class="fa-solid fa-play"></i> Watch Trailer</button>`:""}<a class="secondary-btn" href="./search.html?genre=${encodeURIComponent(genres[0]||"")}">More ${esc(genres[0]||"Movies")}</a></div>
      </div></div>
      <nav class="movie-swipe-nav" aria-label="Browse movies">
        <button type="button" id="previousMovie" ${hasPrevious?"":"disabled"}><i class="fa-solid fa-chevron-left"></i><span>Previous movie</span></button>
        <span>${currentIndex>=0?currentIndex+1:1} <small>/ ${allMovies.length}</small> · Swipe to switch</span>
        <button type="button" id="nextMovie" ${hasNext?"":"disabled"}><span>Next movie</span><i class="fa-solid fa-chevron-right"></i></button>
      </nav>
      <div id="movieCommunity"></div>`;
    addCommunityStyles(); renderCommunity(); renderSimilar(movie);
    const castSliderEl=$("castSlider");
    if(castSliderEl && !castSliderEl._actorBound){
      castSliderEl._actorBound=true;
      castSliderEl.addEventListener("click",function(e){
        const card=e.target.closest(".cast-card.is-clickable"); if(!card)return;
        if(window.CineActor) window.CineActor.open(card.dataset.personId, card.dataset.personName);
      });
    }
    document.querySelectorAll("[data-season-toggle]").forEach(btn=>btn.addEventListener("click",()=>{
      const panel=document.getElementById("season-panel-"+btn.dataset.seasonToggle);
      if(!panel)return;
      const open=panel.hidden;
      panel.hidden=!open;
      btn.setAttribute("aria-expanded",String(open));
      btn.classList.toggle("is-open",open);
    }));
    document.querySelectorAll("[data-cast-dir]").forEach(btn=>btn.addEventListener("click",()=>{
      const sl=$("castSlider"); if(!sl)return;
      sl.scrollBy({left:Number(btn.dataset.castDir)*Math.max(200,sl.clientWidth*0.8),behavior:"smooth"});
    }));
    const prev=$("previousMovie"), next=$("nextMovie");
    if(prev) prev.addEventListener("click",()=>switchMovie(currentIndex-1));
    if(next) next.addEventListener("click",()=>switchMovie(currentIndex+1));
    bindSwipe();
  }
  function switchMovie(index){
    const movies=U.getMovies(); if(index<0||index>=movies.length)return;
    movieId=String(movies[index].id);
    history.replaceState(null,"", "./movie.html?id="+encodeURIComponent(movieId));
    currentMovie=movies[index];
    render(currentMovie);
    window.scrollTo({top:0,behavior:"smooth"});
  }
  function bindSwipe(){
    const area=$("movieDetails"); if(!area||area.dataset.swipeBound)return; area.dataset.swipeBound="1";
    let startX=0,startY=0,skipSwipe=false;
    area.addEventListener("touchstart",e=>{if(!e.touches||!e.touches[0])return;startX=e.touches[0].clientX;startY=e.touches[0].clientY;skipSwipe=!!(e.target.closest&&e.target.closest(".cast-slider"));},{passive:true});
    area.addEventListener("touchend",e=>{if(skipSwipe||!e.changedTouches||!e.changedTouches[0])return;const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY;if(Math.abs(dx)>65&&Math.abs(dx)>Math.abs(dy)*1.25){const movies=U.getMovies(),idx=movies.findIndex(m=>String(m.id)===String(currentMovie.id));switchMovie(idx+(dx<0?1:-1));}},{passive:true});
    document.addEventListener("keydown",e=>{if(e.key!=="ArrowLeft"&&e.key!=="ArrowRight")return;if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))return;const movies=U.getMovies(),idx=movies.findIndex(m=>String(m.id)===String(currentMovie.id));switchMovie(idx+(e.key==="ArrowRight"?1:-1));});
  }
  function start(){
    const movie=movieId?U.getMovieById(movieId):null;
    U.setupHeader();U.setupWatchlistButtons();
    if(!movie){renderNotFound();return;}
    currentMovie=movie;render(movie);
  }
  start();
})();