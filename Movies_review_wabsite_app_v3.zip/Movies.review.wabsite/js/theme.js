(function () {
  "use strict";

  // Day / night switch. The choice is saved in this browser.
  // The early script in <head> applies the saved theme before the page paints.

  const KEY = "cinereview_theme";

  function current() {
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  }

  function paint(button) {
    if (!button) return;
    const isLight = current() === "light";
    button.innerHTML = '<i class="fa-solid ' + (isLight ? "fa-moon" : "fa-sun") + '"></i>';
    button.setAttribute("aria-label", isLight ? "Switch to night mode" : "Switch to day mode");
    button.setAttribute("title", isLight ? "Night mode" : "Day mode");
  }

  function apply(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme === "light" ? "#f5f6f8" : "#09090d");
    try { localStorage.setItem(KEY, theme); } catch (error) {}
  }

  function start() {
    const button = document.getElementById("themeToggle");
    paint(button);
    if (!button) return;
    button.addEventListener("click", function () {
      apply(current() === "light" ? "dark" : "light");
      paint(button);
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
