(function () {
  "use strict";

  // Helpers used by search, cards and details.
  function todayISO() {
    const d = new Date();
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }

  // A movie is upcoming when its release date is in the future.
  function isUpcoming(m) {
    const r = m && m.releaseDate;
    return !!r && /^\d{4}-\d{2}-\d{2}$/.test(r) && r > todayISO();
  }

  function releaseLabel(m) {
    const r = m && m.releaseDate;
    if (!r || !/^\d{4}-\d{2}-\d{2}$/.test(r)) return "";
    const d = new Date(r + "T00:00:00");
    return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
  }

  function norm(s) {
    return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  }

  function levenshtein(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    let prev = Array.from({ length: b.length + 1 }, function (_, i) { return i; });
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      prev = cur;
    }
    return prev[b.length];
  }

  // Best library titles for a (possibly misspelled) query. Returns up to `limit` movies.
  function didYouMean(query, movies, limit) {
    const q = norm(query);
    if (!q) return [];
    const scored = [];
    movies.forEach(function (m) {
      const t = norm(m.title);
      if (!t) return;
      const dist = Math.min(levenshtein(q, t), t.indexOf(q) !== -1 ? 0 : 99);
      const words = t.split(" ");
      const wordDist = Math.min.apply(null, words.map(function (w) { return levenshtein(q, w); }));
      const best = Math.min(dist, wordDist);
      const limitDist = Math.max(2, Math.floor(q.length * 0.34));
      if (best <= limitDist) scored.push({ m: m, s: best });
    });
    scored.sort(function (a, b) { return a.s - b.s; });
    return scored.slice(0, limit || 3).map(function (x) { return x.m; });
  }

  // Live suggestions while typing (contains match, best first)
  function suggestions(query, movies, limit) {
    const q = norm(query);
    if (!q) return [];
    const hits = movies.filter(function (m) { return norm(m.title).indexOf(q) !== -1; });
    return hits.slice(0, limit || 6);
  }

  window.CineSmart = { isUpcoming: isUpcoming, releaseLabel: releaseLabel, todayISO: todayISO, didYouMean: didYouMean, suggestions: suggestions };
})();
