(function () {
  "use strict";

  // Shows the number of saved movies next to every "Watchlist" link.
  const KEY = "cinereview_watchlist";

  function count() {
    try {
      const list = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(list) ? list.length : 0;
    } catch (e) { return 0; }
  }

  function paint() {
    const n = count();
    document.querySelectorAll("[data-wl-count]").forEach(function (el) {
      el.textContent = n ? String(n) : "";
      el.classList.toggle("is-empty", n === 0);
    });
  }

  paint();
  window.addEventListener("storage", paint);
  document.addEventListener("click", function (e) {
    if (e.target.closest && e.target.closest("[data-watchlist]")) {
      setTimeout(paint, 30);
    }
  });
  window.addEventListener("cine:watchlist-changed", paint);
})();
