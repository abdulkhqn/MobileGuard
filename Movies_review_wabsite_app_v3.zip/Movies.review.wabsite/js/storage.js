(function () {
  "use strict";

  const STORAGE_KEY = "cinereview_movies_v1";
  const DELETED_KEY = "cinereview_deleted_builtin_v1";

  // Built-in (starter) movie ids the admin deleted. Kept so they are not re-added on reload.
  function getDeletedIds() {
    try {
      const list = JSON.parse(localStorage.getItem(DELETED_KEY) || "[]");
      return Array.isArray(list) ? list.map(String) : [];
    } catch (error) { return []; }
  }

  function setDeletedIds(list) {
    try { localStorage.setItem(DELETED_KEY, JSON.stringify(list)); } catch (error) {
      console.error("Unable to save deleted list:", error);
    }
  }

  function cloneMovies(movies) {
    return JSON.parse(JSON.stringify(movies || []));
  }

  function saveMovies(movies) {
    if (!Array.isArray(movies)) {
      throw new Error("Movies must be an array.");
    }

    const present = new Set(movies.filter(Boolean).map(function (m) { return String(m.id); }));
    let deleted = getDeletedIds();

    (window.MOVIE_DATA || []).forEach(function (starterMovie) {
      const id = String(starterMovie.id);
      if (!present.has(id) && deleted.indexOf(id) === -1) deleted.push(id);
      if (present.has(id)) deleted = deleted.filter(function (x) { return x !== id; });
    });
    setDeletedIds(deleted);

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(movies)
    );

    return true;
  }

  function legacyGetMovies() {
    let saved = null;
    try { saved = localStorage.getItem(STORAGE_KEY); } catch (error) {
      console.error("LocalStorage is not available:", error);
      return cloneMovies(window.MOVIE_DATA);
    }
    const deletedIds = getDeletedIds();
    const starter = cloneMovies(window.MOVIE_DATA).filter(function (m) {
      return deletedIds.indexOf(String(m.id)) === -1;
    });
    if (saved === null) {
      try { saveMovies(starter); } catch (error) { console.error("Unable to save starter movies:", error); }
      return starter;
    }
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        // New built-in titles are added automatically; existing user/admin entries are preserved.
        const byId = new Map();
        starter.forEach(movie => byId.set(String(movie.id), movie));
        parsed.forEach(movie => { if (movie && movie.id != null) byId.set(String(movie.id), movie); });
        // Older saved copies may not have seasons yet; fill them from the built-in data.
        const starterById = new Map(starter.map(m => [String(m.id), m]));
        parsed.forEach(movie => {
          const base = movie && starterById.get(String(movie.id));
          if (base && !("seasons" in movie) && Array.isArray(base.seasons)) {
            movie.seasons = cloneMovies(base.seasons);
          }
        });
        const merged = Array.from(byId.values());
        if (merged.length !== parsed.length) {
          try { saveMovies(merged); } catch (error) { console.error("Unable to update starter movies:", error); }
        }
        return merged;
      }
    } catch (error) { console.error("Saved movies could not be read:", error); }
    return starter;
  }

  // ---------- Cloud (Supabase) layer ----------
  // The website reads the movie list from Supabase and caches it locally.
  // If the cloud is unreachable, the cached list (or built-in data) is used.
  const REMOTE_KEY = "cinereview_remote_v1";
  const cfg = window.CINE_SUPABASE || {};

  function readRemoteCache() {
    try {
      const v = JSON.parse(localStorage.getItem(REMOTE_KEY) || "null");
      return Array.isArray(v) ? v : null;
    } catch (e) { return null; }
  }

  function getMovies() {
    const cached = readRemoteCache();
    if (cached) return cloneMovies(cached);
    return legacyGetMovies();
  }

  async function refreshFromCloud() {
    if (!cfg.url || !cfg.anonKey) return { changed: false, error: "not configured" };
    const r = await fetch(cfg.url.replace(/\/$/, "") + "/rest/v1/movies?select=id,data", {
      headers: { apikey: cfg.anonKey, Authorization: "Bearer " + cfg.anonKey }
    });
    if (!r.ok) throw new Error("FETCH_FAILED_" + r.status);
    const rows = await r.json();
    const list = rows
      .map(function (row) { return row.data; })
      .filter(Boolean)
      .sort(function (a, b) { return (a._pos == null ? 1e9 : a._pos) - (b._pos == null ? 1e9 : b._pos); });
    const prev = readRemoteCache();
    const changed = !prev || JSON.stringify(prev) !== JSON.stringify(list);
    try { localStorage.setItem(REMOTE_KEY, JSON.stringify(list)); } catch (e) {}
    return { changed: changed, count: list.length };
  }

  // On load: pull the latest list. If it changed, reload once so every part of the page uses it.
  refreshFromCloud()
    .then(function (result) {
      if (result && result.changed) {
        window.location.reload();
      }
    })
    .catch(function (error) {
      console.warn("Cloud movies unavailable, using saved list:", error && error.message);
    });

  function getMovieById(id) {
    return getMovies().find(function (movie) {
      return movie && String(movie.id) === String(id);
    }) || null;
  }

  // Cast can be an old list of names ["Actor"] or new objects [{name, photo}].
  function normalizeCast(value) {
    const list = Array.isArray(value) ? value : String(value || "").split(",");
    return list.map(function (item) {
      if (typeof item === "string") return { name: item.trim(), photo: "" };
      if (item && typeof item === "object") {
        return {
          name: String(item.name || "").trim(),
          photo: String(item.photo || "").trim(),
          id: item.id ? Number(item.id) || 0 : 0
        };
      }
      return { name: "", photo: "" };
    }).filter(function (c) { return c.name; });
  }

  function normalizeSeasons(value) {
    if (!Array.isArray(value)) return [];
    return value.map(function (item, index) {
      const number = Number(item && item.number) || index + 1;
      const episodes = Math.max(0, Math.floor(Number(item && item.episodes) || 0));
      return { number: number, episodes: episodes };
    }).filter(function (s) { return s.episodes > 0; });
  }

  window.CineStorage = {
    normalizeSeasons: normalizeSeasons,
    getMovies: getMovies,
    refreshFromCloud: refreshFromCloud,
    saveMovies: saveMovies,
    getMovieById: getMovieById,
    normalizeCast: normalizeCast
  };
})();
