(function () {
  "use strict";

  // Bell button in the header + notification panel.
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  const bell = document.getElementById("notifToggle");
  if (!bell || !window.CineRequests) return;

  let items = [];

  const panel = document.createElement("div");
  panel.className = "notif-overlay";
  panel.hidden = true;
  panel.innerHTML =
    '<div class="notif-sheet" role="dialog" aria-modal="true" aria-labelledby="notifTitle">' +
      '<div class="notif-head"><h3 id="notifTitle"><i class="fa-solid fa-bell"></i> Notifications</h3>' +
      '<button type="button" class="notif-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>' +
      '<div class="notif-list"></div>' +
    '</div>';
  document.body.appendChild(panel);

  function unseenCount() {
    const s = new Set(window.CineRequests.seen());
    return items.filter(function (n) { return !s.has(String(n.id)); }).length;
  }

  function paintBadge() {
    const n = unseenCount();
    bell.dataset.count = n ? String(n) : "";
    bell.classList.toggle("has-new", n > 0);
  }

  function render() {
    const list = panel.querySelector(".notif-list");
    if (!items.length) {
      list.innerHTML = '<div class="notif-empty"><i class="fa-regular fa-bell"></i><p>No notifications yet.</p></div>';
      return;
    }
    list.innerHTML = items.map(function (n, i) {
      const isNew = window.CineRequests.seen().indexOf(String(n.id)) === -1;
      const date = n.created_at ? new Date(n.created_at).toLocaleDateString() : "";
      return '<div class="notif-item' + (isNew ? " is-new" : "") + '" style="--i:' + i + '">' +
        '<span class="notif-dot"></span>' +
        '<div><strong>' + esc(n.title || "Movie request approved") + '</strong>' +
        '<p>' + esc(String(n.message || "").split("\n\n")[0]) + '</p>' +
        (n.movie_title ? '<small>Movie: ' + esc(n.movie_title) + '</small>' : '') +
        (date ? '<small class="notif-date">' + esc(date) + '</small>' : '') +
        '</div></div>';
    }).join("");
  }

  function close() {
    panel.classList.remove("open");
    document.body.style.overflow = "";
    setTimeout(function () { panel.hidden = true; }, 240);
  }

  async function open() {
    panel.hidden = false;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(function () { panel.classList.add("open"); });
    render();
    // mark as seen after the panel was shown
    window.CineRequests.markSeen(items.map(function (n) { return String(n.id); }));
    setTimeout(function () { render(); paintBadge(); }, 600);
  }

  bell.addEventListener("click", open);
  panel.addEventListener("click", function (e) {
    if (e.target === panel || e.target.closest(".notif-close")) close();
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });

  async function load() {
    try {
      items = await window.CineRequests.notifications();
    } catch (e) {
      items = [];
    }
    paintBadge();
  }
  load();
  setInterval(load, 60000);
})();
