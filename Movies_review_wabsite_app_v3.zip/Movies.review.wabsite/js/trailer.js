(function () {
  "use strict";

  // Plays YouTube trailers inside the site (no new tab).
  function keyFrom(url) {
    const m = String(url || "").match(/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_-]{6,})/);
    return m ? m[1] : "";
  }

  let overlay = null;

  function build() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.className = "trailer-overlay";
    overlay.hidden = true;
    overlay.innerHTML =
      '<div class="trailer-box" role="dialog" aria-modal="true" aria-label="Trailer">' +
        '<div class="trailer-bar"><span><i class="fa-solid fa-film"></i> Trailer</span>' +
        '<button type="button" class="trailer-close" aria-label="Close"><i class="fa-solid fa-xmark"></i></button></div>' +
        '<div class="trailer-frame"><div class="trailer-loading"><span></span><span></span><span></span></div></div>' +
        '<p class="trailer-fallback" hidden>This video can\'t play here. <a target="_blank" rel="noopener" href="#">Watch on YouTube</a></p>' +
      '</div>';
    document.body.appendChild(overlay);
    overlay.addEventListener("click", function (e) {
      if (e.target === overlay || e.target.closest(".trailer-close")) close();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    return overlay;
  }

  function open(url) {
    const key = keyFrom(url);
    if (!key) { window.open(url, "_blank", "noopener"); return; }
    const el = build();
    const frame = el.querySelector(".trailer-frame");
    const fallback = el.querySelector(".trailer-fallback");
    fallback.querySelector("a").href = "https://www.youtube.com/watch?v=" + key;
    fallback.hidden = true;
    frame.innerHTML =
      '<iframe src="https://www.youtube-nocookie.com/embed/' + key + '?autoplay=1&rel=0&modestbranding=1" ' +
      'title="Trailer" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe>';
    el.hidden = false;
    document.body.style.overflow = "hidden";
    requestAnimationFrame(function () { el.classList.add("open"); });
  }

  function close() {
    if (!overlay || overlay.hidden) return;
    overlay.classList.remove("open");
    document.body.style.overflow = "";
    const frame = overlay.querySelector(".trailer-frame");
    setTimeout(function () { overlay.hidden = true; frame.innerHTML = ""; }, 260);
  }

  document.addEventListener("click", function (e) {
    const btn = e.target.closest && e.target.closest("[data-trailer-play]");
    if (!btn) return;
    e.preventDefault();
    open(btn.dataset.trailerPlay);
  });

  window.CineTrailer = { open: open, close: close };
})();
