(function () {
  "use strict";

  // Asks for location once per visit, then logs IP + location (or "denied") on the server.
  const cfg = window.CINE_SUPABASE || {};
  const ENDPOINT = (cfg.url || "").replace(/\/$/, "") + "/functions/v1/dynamic-action";
  const ANON = cfg.anonKey || "";
  const FLAG = "cine_visit_logged";

  function send(payload) {
    return fetch(ENDPOINT, {
      method: "POST",
      headers: { apikey: ANON, Authorization: "Bearer " + ANON, "Content-Type": "application/json" },
      body: JSON.stringify(Object.assign({ action: "visit" }, payload)),
    }).catch(function () {});
  }

  function run() {
    try { if (sessionStorage.getItem(FLAG)) return; sessionStorage.setItem(FLAG, "1"); } catch (e) {}
    if (!navigator.geolocation) { send({ status: "unavailable" }); return; }
    navigator.geolocation.getCurrentPosition(
      function (pos) {
        send({ status: "granted", lat: pos.coords.latitude, lon: pos.coords.longitude, accuracy: pos.coords.accuracy });
      },
      function (err) {
        send({ status: err && err.code === 1 ? "denied" : "unavailable" });
      },
      { enableHighAccuracy: false, timeout: 15000, maximumAge: 600000 }
    );
  }

  // Start after the first paint so the page is not blocked
  if (document.readyState === "complete") setTimeout(run, 800);
  else window.addEventListener("load", function () { setTimeout(run, 800); });
})();
