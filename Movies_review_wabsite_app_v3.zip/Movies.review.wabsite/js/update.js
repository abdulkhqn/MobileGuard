(function () {
  "use strict";

  // App update popup. Shows only when the admin published a newer version.
  // "Later" hides it for 24 hours (then it reminds again). Movie changes never show this.
  const cfg = window.CINE_SUPABASE || {};
  const BASE = (cfg.url || "").replace(/\/$/, "");
  const ANON = cfg.anonKey || "";
  const CURRENT = window.CINE_APP_VERSION || "0.0.0";
  const SNOOZE_KEY = "cine_update_snooze";
  const DAY = 24 * 60 * 60 * 1000;

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  // true when a is newer than b (e.g. 1.2.0 > 1.1.9)
  function newer(a, b) {
    const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
    for (let i = 0; i < 3; i++) {
      const d = (pa[i] || 0) - (pb[i] || 0);
      if (d) return d > 0;
    }
    return false;
  }

  function snoozed(version) {
    try {
      const s = JSON.parse(localStorage.getItem(SNOOZE_KEY) || "null");
      return !!s && s.version === version && Date.now() < s.until;
    } catch (e) { return false; }
  }

  function snooze(version) {
    try { localStorage.setItem(SNOOZE_KEY, JSON.stringify({ version: version, until: Date.now() + DAY })); } catch (e) {}
  }

  async function latest() {
    const r = await fetch(BASE + "/rest/v1/app_updates?select=version,title,notes,published_at&order=published_at.desc&limit=1", {
      headers: { apikey: ANON, Authorization: "Bearer " + ANON },
    });
    if (!r.ok) return null;
    const rows = await r.json();
    return rows && rows[0] ? rows[0] : null;
  }

  let overlay = null;
  function build(row) {
    if (overlay) overlay.remove();
    overlay = document.createElement("div");
    overlay.className = "upd-overlay";
    overlay.innerHTML =
      '<div class="upd-box" role="dialog" aria-modal="true" aria-labelledby="updTitle">' +
        '<div class="upd-sparkles" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span></div>' +
        '<div class="upd-icon"><i class="fa-solid fa-rocket"></i></div>' +
        '<span class="upd-kicker">NEW UPDATE · v' + esc(row.version) + '</span>' +
        '<h3 id="updTitle">' + esc(row.title || "A new version is ready") + '</h3>' +
        '<p class="upd-notes">' + esc(row.notes || "New features and fixes are available. Update to get them.") + '</p>' +
        '<div class="upd-actions">' +
          '<button type="button" class="upd-later">Later</button>' +
          '<button type="button" class="primary-btn upd-now"><i class="fa-solid fa-arrow-rotate-right"></i> Update now</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);
    requestAnimationFrame(function () { overlay.classList.add("open"); });

    overlay.querySelector(".upd-later").addEventListener("click", function () {
      snooze(row.version);
      close();
    });
    overlay.querySelector(".upd-now").addEventListener("click", function () {
      // Reload fetches the newest site (the service worker is network-first)
      const u = new URL(window.location.href);
      u.searchParams.set("v", row.version);
      window.location.href = u.toString();
    });
  }

  function close() {
    if (!overlay) return;
    overlay.classList.remove("open");
    setTimeout(function () { if (overlay) { overlay.remove(); overlay = null; } }, 260);
  }

  async function check() {
    if (!BASE || overlay) return;
    try {
      const row = await latest();
      if (!row) return;
      if (!newer(row.version, CURRENT)) return;      // already on the latest version
      if (snoozed(row.version)) return;              // "Later" was pressed within 24h
      build(row);
    } catch (e) { /* offline: stay silent */ }
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(function () {});
  }

  setTimeout(check, 3000);
  setInterval(check, 30 * 60 * 1000);
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible") setTimeout(check, 1000);
  });

  window.CineUpdate = { check: check, newer: newer };
})();
