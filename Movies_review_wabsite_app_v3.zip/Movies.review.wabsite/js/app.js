(function () {
  "use strict";

  const genres = window.GENRE_DATA || [];

  const $ = (selector) => document.querySelector(selector);

  // Escapes text so it can be safely placed inside HTML and attributes.
  function escapeHTML(value) {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };

    return String(value ?? "").replace(/[&<>"']/g, function (char) {
      return entities[char];
    });
  }

  // Always reads the latest saved movies (LocalStorage) at render time.
  function getMovieList() {
    let list = [];

    try {
      list = window.CineStorage
        ? window.CineStorage.getMovies()
        : (window.MOVIE_DATA || []);
    } catch (error) {
      console.error("Unable to load movies:", error);
      list = window.MOVIE_DATA || [];
    }

    if (!Array.isArray(list)) return [];

    return list.filter(function (movie) {
      return movie && typeof movie === "object";
    });
  }

  function getWatchlist() {
    try {
      const stored = JSON.parse(
        localStorage.getItem("cinereview_watchlist") || "[]"
      );

      return Array.isArray(stored) ? stored : [];
    } catch (error) {
      return [];
    }
  }

  function showToast(message, type = "success") {
    const container = $("#toastContainer");

    if (!container) return;

    const toast = document.createElement("div");
    toast.className = "toast " + type;
    toast.textContent = message;

    container.appendChild(toast);

    window.setTimeout(function () {
      toast.remove();
    }, 2800);
  }

  // Supports external URLs (https/http), data/blob/file URLs
  // and local relative paths such as assets/posters/movie-1.jpg
  function getPosterURL(value) {
    const poster = String(value || "").trim();

    if (!poster) return "";

    if (/^(https?:|data:image\/|blob:|file:)/i.test(poster) ||
        poster.indexOf("//") === 0) {
      return poster;
    }

    return "./" + poster.replace(/^(\.\/|\/)+/, "");
  }

  // Release time used for the "Latest" section.
  function getReleaseTime(movie) {
    const parsed = Date.parse(movie.releaseDate);

    if (!isNaN(parsed)) return parsed;

    const year = Number(movie.year);

    return Number.isFinite(year) ? Date.UTC(year, 0, 1) : 0;
  }

  function createMovieCard(movie) {
    const saved = getWatchlist().some(function (id) {
      return String(id) === String(movie.id);
    });

    const title = escapeHTML(movie.title);
    const year = escapeHTML(movie.year);
    const genre = escapeHTML(
      Array.isArray(movie.genres) && movie.genres.length
        ? movie.genres[0]
        : "Movie"
    );
    const rating = Number(movie.rating);

    const safeRating = Number.isFinite(rating)
      ? Math.max(0, Math.min(10, rating)).toFixed(1)
      : "N/A";

    const posterURL = escapeHTML(getPosterURL(movie.poster));
    const movieId = encodeURIComponent(movie.id);

    const posterHTML = posterURL
      ? `
        <img
          class="movie-poster"
          src="${posterURL}"
          alt="${title} poster"
          loading="lazy"
          onerror="this.style.display='none';var p=this.nextElementSibling;if(p){p.style.display='flex';}"
        >
        <div class="movie-poster-placeholder" style="display:none">
          <i class="fa-solid fa-film"></i>
          <span>${title}</span>
        </div>
      `
      : `
        <div class="movie-poster-placeholder">
          <i class="fa-solid fa-film"></i>
          <span>${title}</span>
        </div>
      `;

    return `
      <article class="movie-card">

        <div class="movie-poster-wrap">
          <a class="movie-poster-link" href="./movie.html?id=${movieId}" aria-label="View details for ${title}">
            ${posterHTML}
          </a>

          <span class="rating-badge">
            <i class="fa-solid fa-star"></i>
            ${safeRating}
          </span>

          <button
            class="watchlist-btn ${saved ? "saved" : ""}"
            data-watchlist="${escapeHTML(movie.id)}"
            aria-label="${saved ? "Remove from" : "Add to"} watchlist"
            aria-pressed="${saved}"
            type="button"
          >
            <i class="fa-${saved ? "solid" : "regular"} fa-bookmark"></i>
          </button>
        </div>

        <div class="movie-info">
          <a
            class="movie-title"
            href="./movie.html?id=${movieId}"
          >${title}</a>

          <div class="movie-meta">
            <span>${year}</span>
            <span class="meta-dot"></span>
            <span>${escapeHTML(movie.language || "English")}</span>
          </div>

          <span class="movie-genre">${genre}</span>
        </div>

      </article>
    `;
  }

  function renderMovies(gridId, movieList) {
    const grid = document.getElementById(gridId);

    if (!grid) return;

    if (!movieList.length) {
      grid.innerHTML = `
        <div class="empty-state">
          <i class="fa-solid fa-film"></i>
          <h3>No movies available</h3>
          <p>Movies will appear here when they are added.</p>
        </div>
      `;

      return;
    }

    grid.innerHTML = movieList.map(createMovieCard).join("");
  }

  function renderGenres() {
    const grid = $("#genreGrid");

    if (!grid) return;

    grid.innerHTML = genres.map(function (genre) {
      const name = escapeHTML(genre.name);
      const icon = escapeHTML(genre.icon);
      const description = escapeHTML(genre.description);

      return `
        <a
          class="genre-card"
          href="./search.html?genre=${encodeURIComponent(genre.name)}"
        >
          <div class="genre-icon">
            <i class="fa-solid ${icon}"></i>
          </div>

          <div>
            <h3>${name}</h3>
            <p>${description}</p>
          </div>
        </a>
      `;
    }).join("");
  }

  let trendingPage = 1;
  const PAGE_SIZE = 10;
  let trendingItems = [];

  function renderTrendingPage() {
    const pageCount = Math.max(1, Math.ceil(trendingItems.length / PAGE_SIZE));
    trendingPage = Math.min(Math.max(1, trendingPage), pageCount);
    const start = (trendingPage - 1) * PAGE_SIZE;
    renderMovies("trendingGrid", trendingItems.slice(start, start + PAGE_SIZE));
    const status = $("#pageStatus");
    const prev = $("#prevMovies");
    const next = $("#nextMovies");
    if (status) status.textContent = "Page " + trendingPage + " of " + pageCount;
    if (prev) prev.disabled = trendingPage <= 1;
    if (next) next.disabled = trendingPage >= pageCount;
  }

  function setupMoviePagination() {
    const prev = $("#prevMovies");
    const next = $("#nextMovies");
    if (prev) prev.addEventListener("click", function () {
      if (trendingPage > 1) { trendingPage--; renderTrendingPage(); document.getElementById("trending").scrollIntoView({behavior:"smooth",block:"start"}); }
    });
    if (next) next.addEventListener("click", function () {
      if (trendingPage < Math.ceil(trendingItems.length / PAGE_SIZE)) { trendingPage++; renderTrendingPage(); document.getElementById("trending").scrollIntoView({behavior:"smooth",block:"start"}); }
    });
  }

  function setupTopRatedMenu() {
    const link = $("#topRatedNav");
    const section = $("#topRated");
    if (!link || !section) return;
    link.addEventListener("click", function (event) {
      event.preventDefault();
      section.hidden = false;
      section.classList.add("section-reveal");
      section.scrollIntoView({behavior:"smooth",block:"start"});
    });
    const trendingLink = document.querySelector('#mainNav a[href="#trending"]');
    if (trendingLink) trendingLink.addEventListener("click", function () {
      section.hidden = true;
    });
  }

  function renderHomepage() {
    const currentMovies = getMovieList();

    const today = window.CineSmart && window.CineSmart.todayISO
      ? window.CineSmart.todayISO()
      : new Date().toISOString().slice(0, 10);

    // Date-driven sections update automatically: when release day arrives,
    // a title leaves Upcoming and appears in Latest without admin edits.
    const upcoming = currentMovies.filter(function (movie) {
      const date = String(movie.releaseDate || "").slice(0, 10);
      return /^\d{4}-\d{2}-\d{2}$/.test(date) && date > today;
    }).sort(function (a, b) {
      return getReleaseTime(a) - getReleaseTime(b);
    });

    const latest = currentMovies.filter(function (movie) {
      const date = String(movie.releaseDate || "").slice(0, 10);
      return !date || !/^\d{4}-\d{2}-\d{2}$/.test(date) || date <= today;
    }).sort(function (a, b) {
      return getReleaseTime(b) - getReleaseTime(a);
    });

    const trending = currentMovies.filter(function (movie) {
      const date = String(movie.releaseDate || "").slice(0, 10);
      return (movie.trending === true || movie.trending === "true") &&
        (!/^\d{4}-\d{2}-\d{2}$/.test(date) || date <= today);
    });

    const topRated = currentMovies.slice().sort(function (a, b) {
      return (Number(b.rating) || 0) - (Number(a.rating) || 0);
    });

    // Keep Trending titles first, then include the rest of the catalogue across later pages.
    const trendingIds = new Set(trending.map(function (movie) { return String(movie.id); }));
    trendingItems = trending.concat(currentMovies.filter(function (movie) {
      return !trendingIds.has(String(movie.id));
    }));
    // Show exactly 10 cards per page; the pager moves through the complete collection.
    renderTrendingPage();
    // Render only the first 10 cards in these sections to keep mobile scrolling light.
    renderMovies("upcomingGrid", upcoming.slice(0, 10));
    renderMovies("latestGrid", latest.slice(0, 10));
    renderGenres();

    const count = $("#movieCount");

    if (count) {
      count.textContent = String(currentMovies.length);
    }

    const year = $("#currentYear");

    if (year) {
      year.textContent = String(new Date().getFullYear());
    }
  }

  function setupSearch() {
    const toggle = $("#searchToggle");
    const panel = $("#searchPanel");
    const input = $("#globalSearch");
    const form = $("#searchForm");

    if (toggle && panel) {
      toggle.addEventListener("click", function () {
        panel.classList.toggle("open");

        if (panel.classList.contains("open") && input) {
          input.focus();
        }
      });
    }

    if (form && input) {
      form.addEventListener("submit", function (event) {
        event.preventDefault();

        const query = input.value.trim();

        if (!query) {
          showToast("Enter a movie title first.", "error");
          input.focus();
          return;
        }

        window.location.href =
          "./search.html?q=" + encodeURIComponent(query);
      });
    }
  }

  function setupMobileMenu() {
    const button = $("#menuToggle");
    const nav = $("#mainNav");

    if (!button || !nav) return;

    button.addEventListener("click", function () {
      const open = nav.classList.toggle("mobile-open");

      button.setAttribute("aria-expanded", String(open));

      button.innerHTML = open
        ? '<i class="fa-solid fa-xmark"></i>'
        : '<i class="fa-solid fa-bars"></i>';
    });

    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("mobile-open");
        button.setAttribute("aria-expanded", "false");
        button.innerHTML = '<i class="fa-solid fa-bars"></i>';
      });
    });
  }

  function setupWatchlistButtons() {
    document.addEventListener("click", function (event) {
      const button = event.target.closest("[data-watchlist]");

      if (!button) return;

      const movieId = button.dataset.watchlist;
      let watchlist = getWatchlist();

      const alreadySaved = watchlist.some(function (id) {
        return String(id) === String(movieId);
      });

      if (alreadySaved) {
        watchlist = watchlist.filter(function (id) {
          return String(id) !== String(movieId);
        });

        showToast("Removed from watchlist.");
      } else {
        watchlist.push(movieId);
        showToast("Added to watchlist.");
      }

      try {
        localStorage.setItem(
          "cinereview_watchlist",
          JSON.stringify(watchlist)
        );
      } catch (error) {
        showToast("Unable to save. Check browser storage.", "error");
        return;
      }

      const saved = !alreadySaved;

      button.classList.toggle("saved", saved);
      button.setAttribute("aria-pressed", String(saved));

      button.innerHTML = saved
        ? '<i class="fa-solid fa-bookmark"></i>'
        : '<i class="fa-regular fa-bookmark"></i>';

      button.setAttribute(
        "aria-label",
        saved ? "Remove from watchlist" : "Add to watchlist"
      );
    });
  }

  // Keeps the homepage fresh when the user comes back from the Admin Panel
  // (back button / cached page) or edits movies in another tab.
  function setupAutoRefresh() {
    window.addEventListener("pageshow", function (event) {
      if (event.persisted) {
        renderHomepage();
      }
    });

    window.addEventListener("storage", function (event) {
      if (event.key === "cinereview_movies_v1") {
        renderHomepage();
      }
    });
  }

  function start() {
    renderHomepage();
    setupSearch();
    setupMoviePagination();
    setupTopRatedMenu();
    setupMobileMenu();
    setupWatchlistButtons();
    setupAutoRefresh();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
