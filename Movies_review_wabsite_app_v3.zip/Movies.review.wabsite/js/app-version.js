// Version of THIS deployed website. When you publish a new version in the admin,
// the users' sites with an older number show the update popup.
window.CINE_APP_VERSION = "1.0.0";
