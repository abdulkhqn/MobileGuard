// Supabase connection for the public website (read-only, anon key is public-safe).
window.CINE_SUPABASE = {
  url: "https://mroucdhaaukfsvrtefbn.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1yb3VjZGhhYXVrZnN2cnRlZmJuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMwMDEwMzQsImV4cCI6MjEwODU3NzAzNH0.1B6KqDuDnx9JYxieVJ18gSpIEpWLmcnO--_o3MnCFt4"
};
