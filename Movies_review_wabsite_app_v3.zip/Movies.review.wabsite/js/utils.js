(function () {
  "use strict";

  // Shared helpers for the secondary pages (movie.html and search.html).
  // index.html keeps using app.js; this file does not change app.js behaviour.
  // It reads movies through CineStorage (same LocalStorage key as admin.js),
  // so admin-added movies appear here too.

  const WATCHLIST_KEY = "cinereview_watchlist";

  function escapeHTML(value) {
    const entities = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    };

    return String(value ?? "").replace(/[&<>"']/g, function (char) {
      return entities[char];
    });
  }

  // External http/https/data/blob URLs are used as-is.
  // Anything else is treated as a local path, e.g. assets/posters/movie-1.jpg
  function getPosterURL(value) {
    const poster = String(value || "").trim();

    if (!poster) return "";

    if (/^(https?:|data:image\/|blob:|file:)/i.test(poster) ||
        poster.indexOf("//") === 0) {
      return poster;
    }

    return "./" + poster.replace(/^(\.\/|\/)+/, "");
  }

  function getMovies() {
    let list = [];

    try {
      list = window.CineStorage
        ? window.CineStorage.getMovies()
        : (window.MOVIE_DATA || []);
    } catch (error) {
      console.error("Unable to load movies:", error);
      list = window.MOVIE_DATA || [];
    }

    if (!Array.isArray(list)) return [];

    return list.filter(function (movie) {
      return movie && typeof movie === "object";
    });
  }

  function getMovieById(id) {
    const wanted = String(id || "");

    return getMovies().find(function (movie) {
      return String(movie.id) === wanted;
    }) || null;
  }

  function getWatchlist() {
    try {
      const stored = JSON.parse(localStorage.getItem(WATCHLIST_KEY) || "[]");

      return Array.isArray(stored) ? stored : [];
    } catch (error) {
      return [];
    }
  }

  function isSaved(id) {
    return getWatchlist().some(function (item) {
      return String(item) === String(id);
    });
  }

  // Returns { ok, saved }. ok=false means browser storage refused the write.
  function toggleWatchlist(id) {
    const key = String(id);
    const wasSaved = isSaved(key);

    const list = getWatchlist().filter(function (item) {
      return String(item) !== key;
    });

    if (!wasSaved) list.push(key);

    try {
      localStorage.setItem(WATCHLIST_KEY, JSON.stringify(list));
    } catch (error) {
      return { ok: false, saved: wasSaved };
    }

    return { ok: true, saved: !wasSaved };
  }

  function watchlistButtonHTML(id, saved) {
    return `
      <button
        class="watchlist-btn ${saved ? "saved" : ""}"
        data-watchlist="${escapeHTML(id)}"
        aria-label="${saved ? "Remove from" : "Add to"} watchlist"
        aria-pressed="${saved}"
        type="button"
      >
        <i class="fa-${saved ? "solid" : "regular"} fa-bookmark"></i>
      </button>
    `;
  }

  function showToast(message, type = "success") {
    const container = document.getElementById("toastContainer");

    if (!container) return;

    const toast = document.createElement("div");
    toast.className = "toast " + type;
    toast.textContent = message;

    container.appendChild(toast);

    window.setTimeout(function () {
      toast.remove();
    }, 2800);
  }

  function createMovieCard(movie) {
    const saved = isSaved(movie.id);

    const title = escapeHTML(movie.title);
    const year = escapeHTML(movie.year);
    const genre = escapeHTML(
      Array.isArray(movie.genres) && movie.genres.length
        ? movie.genres[0]
        : "Movie"
    );

    const rating = Number(movie.rating);
    const safeRating = Number.isFinite(rating)
      ? Math.max(0, Math.min(10, rating)).toFixed(1)
      : "N/A";

    const posterURL = escapeHTML(getPosterURL(movie.poster));
    const movieId = encodeURIComponent(movie.id);

    const posterHTML = posterURL
      ? `
        <img
          class="movie-poster"
          src="${posterURL}"
          alt="${title} poster"
          loading="lazy"
          onerror="this.style.display='none';var p=this.nextElementSibling;if(p){p.style.display='flex';}"
        >
        <div class="movie-poster-placeholder" style="display:none">
          <i class="fa-solid fa-film"></i>
          <span>${title}</span>
        </div>
      `
      : `
        <div class="movie-poster-placeholder">
          <i class="fa-solid fa-film"></i>
          <span>${title}</span>
        </div>
      `;

    return `
      <article class="movie-card">
        <div class="movie-poster-wrap">
          <a class="movie-poster-link" href="./movie.html?id=${movieId}" aria-label="View details for ${title}">
            ${posterHTML}
          </a>

          <span class="rating-badge">
            ${window.CineSmart && window.CineSmart.isUpcoming(movie) ? '<i class="fa-regular fa-clock"></i> Soon' : '<i class="fa-solid fa-star"></i> ' + safeRating}
          </span>

          ${watchlistButtonHTML(movie.id, saved)}
        </div>

        <div class="movie-info">
          <a class="movie-title" href="./movie.html?id=${movieId}">${title}</a>

          <div class="movie-meta">
            <span>${year}</span>
            <span class="meta-dot"></span>
            <span>${escapeHTML(movie.language || "English")}</span>
          </div>

          <span class="movie-genre">${genre}</span>
        </div>
      </article>
    `;
  }

  // Keeps every watchlist button for the same movie in sync on the page.
  function setupWatchlistButtons() {
    document.addEventListener("click", function (event) {
      const button = event.target.closest("[data-watchlist]");

      if (!button) return;

      const result = toggleWatchlist(button.dataset.watchlist);

      if (!result.ok) {
        showToast("Unable to save. Check browser storage.", "error");
        return;
      }

      showToast(result.saved ? "Added to watchlist." : "Removed from watchlist.");

      document.querySelectorAll("[data-watchlist]").forEach(function (item) {
        if (String(item.dataset.watchlist) !== String(button.dataset.watchlist)) {
          return;
        }

        item.classList.toggle("saved", result.saved);
        item.setAttribute("aria-pressed", String(result.saved));
        item.setAttribute(
          "aria-label",
          result.saved ? "Remove from watchlist" : "Add to watchlist"
        );
        item.innerHTML = result.saved
          ? '<i class="fa-solid fa-bookmark"></i>'
          : '<i class="fa-regular fa-bookmark"></i>';
      });
    });
  }

  // Mobile menu and search toggle, same behaviour as index.html.
  function setupHeader() {
    const $ = function (selector) {
      return document.querySelector(selector);
    };

    const toggle = $("#searchToggle");
    const panel = $("#searchPanel");
    const input = $("#globalSearch");
    const form = $("#searchForm");

    if (toggle && panel) {
      toggle.addEventListener("click", function () {
        panel.classList.toggle("open");

        if (panel.classList.contains("open") && input) {
          input.focus();
        }
      });
    }

    if (form && input) {
      form.addEventListener("submit", function (event) {
        event.preventDefault();

        const query = input.value.trim();

        if (!query) {
          showToast("Enter a movie title first.", "error");
          input.focus();
          return;
        }

        window.location.href = "./search.html?q=" + encodeURIComponent(query);
      });
    }

    const button = $("#menuToggle");
    const nav = $("#mainNav");

    if (button && nav) {
      button.addEventListener("click", function () {
        const open = nav.classList.toggle("mobile-open");

        button.setAttribute("aria-expanded", String(open));
        button.innerHTML = open
          ? '<i class="fa-solid fa-xmark"></i>'
          : '<i class="fa-solid fa-bars"></i>';
      });
    }
  }

  window.CineUtils = {
    escapeHTML: escapeHTML,
    getPosterURL: getPosterURL,
    getMovies: getMovies,
    getMovieById: getMovieById,
    isSaved: isSaved,
    toggleWatchlist: toggleWatchlist,
    watchlistButtonHTML: watchlistButtonHTML,
    showToast: showToast,
    createMovieCard: createMovieCard,
    setupWatchlistButtons: setupWatchlistButtons,
    setupHeader: setupHeader
  };
})();