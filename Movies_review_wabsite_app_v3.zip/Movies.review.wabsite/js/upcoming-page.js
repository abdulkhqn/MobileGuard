(function(){
  "use strict";
  const grid=document.getElementById("upcomingPageGrid");
  if(!grid) return;
  const escapeHTML=v=>String(v==null?"":v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function movies(){try{return window.CineStorage?window.CineStorage.getMovies():(window.MOVIE_DATA||[])}catch(e){return window.MOVIE_DATA||[]}}
  function render(){
    const today=new Date(); const todayISO=[today.getFullYear(),String(today.getMonth()+1).padStart(2,'0'),String(today.getDate()).padStart(2,'0')].join('-');
    const list=movies().filter(m=>{const d=String(m.releaseDate||'').slice(0,10);return /^\d{4}-\d{2}-\d{2}$/.test(d)&&d>todayISO;}).sort((a,b)=>String(a.releaseDate).localeCompare(String(b.releaseDate)));
    document.getElementById('upcomingCount').textContent=list.length+' upcoming '+(list.length===1?'title':'titles');
    document.getElementById('upcomingEmpty').hidden=list.length!==0;
    grid.innerHTML=list.map((m,i)=>{
      const poster=String(m.poster||''); const posterURL=/^(https?:|data:image\/|blob:)/i.test(poster)?poster:'./'+poster.replace(/^(\.\/|\/)+/,'');
      const id=encodeURIComponent(m.id); const title=escapeHTML(m.title); const date=escapeHTML(m.releaseDate);
      const rating=Number(m.rating); const rate=Number.isFinite(rating)?Math.max(0,Math.min(10,rating)).toFixed(1):'N/A';
      const genre=escapeHTML(Array.isArray(m.genres)&&m.genres.length?m.genres[0]:'Movie');
      return `<article class="movie-card upcoming-animated-card" style="--card-order:${Math.min(i,12)}"><div class="movie-poster-wrap"><a class="movie-poster-link" href="./movie.html?id=${id}"><img class="movie-poster" src="${escapeHTML(posterURL)}" alt="${title} poster" loading="lazy" onerror="this.style.display='none'"></a><span class="upcoming-corner-badge">UPCOMING</span><span class="rating-badge"><i class="fa-solid fa-star"></i> ${rate}</span></div><div class="movie-info"><a class="movie-title" href="./movie.html?id=${id}">${title}</a><div class="movie-meta"><span>${escapeHTML(m.year||date.slice(0,4))}</span><span class="meta-dot"></span><span>${date}</span></div><span class="movie-genre">${genre}</span></div></article>`;
    }).join('');
  }
  function start(){render();window.addEventListener('storage',e=>{if(!e.key||e.key==='cinereview_movies_v1')render()});window.addEventListener('pageshow',render);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();