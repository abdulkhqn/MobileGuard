(function () {
  "use strict";

  // Watchlist page: shows only the movies the user saved.
  const KEY = "cinereview_watchlist";
  const grid = document.getElementById("watchlistGrid");
  const countEl = document.getElementById("watchlistCount");

  function savedIds() {
    try {
      const list = JSON.parse(localStorage.getItem(KEY) || "[]");
      return Array.isArray(list) ? list.map(String) : [];
    } catch (e) { return []; }
  }

  function render() {
    if (!grid) return;
    const ids = savedIds();
    const all = window.CineStorage ? window.CineStorage.getMovies() : [];
    const byId = new Map(all.map(function (m) { return [String(m.id), m]; }));

    // Newest saved first
    const movies = ids.slice().reverse().map(function (id) { return byId.get(id); }).filter(Boolean);

    if (countEl) {
      countEl.textContent = movies.length
        ? movies.length + (movies.length === 1 ? " movie saved" : " movies saved")
        : "";
    }

    if (!movies.length) {
      grid.innerHTML =
        '<div class="empty-state"><i class="fa-solid fa-bookmark"></i>' +
        '<h3>Your watchlist is empty</h3>' +
        '<p>Tap the bookmark on any movie to save it here.</p>' +
        '<a class="primary-btn" href="./index.html">Browse movies</a></div>';
      return;
    }

    grid.innerHTML = movies.map(function (m) {
      return window.CineUtils.createMovieCard(m);
    }).join("");
  }

  // Remove a card right away when its bookmark is tapped
  document.addEventListener("click", function (e) {
    if (e.target.closest && e.target.closest("[data-watchlist]")) {
      setTimeout(render, 80);
    }
  });

  window.addEventListener("storage", render);

  if (window.CineUtils) {
    if (typeof window.CineUtils.setupHeader === "function") window.CineUtils.setupHeader();
    if (typeof window.CineUtils.setupWatchlistButtons === "function") window.CineUtils.setupWatchlistButtons();
  }

  render();
})();
