(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const params = new URLSearchParams(window.location.search);
  const state = {
    query: (params.get("q") || "").trim(),
    genre: params.get("genre") || "",
    sort: params.get("sort") || "rating"
  };

  function getMovies() {
    try {
      if (window.CineStorage && typeof window.CineStorage.getMovies === "function") {
        const list = window.CineStorage.getMovies();
        if (Array.isArray(list)) return list.filter(m => m && typeof m === "object");
      }
    } catch (e) { console.error("CineReview: could not read saved movies", e); }
    return Array.isArray(window.MOVIE_DATA) ? window.MOVIE_DATA : [];
  }

  function matches(movie, query) {
    const genres = Array.isArray(movie.genres) ? movie.genres : [movie.genres || ""];
    if (state.genre && !genres.some(g => String(g).toLowerCase() === state.genre.toLowerCase())) return false;
    if (!query) return true;
    const haystack = [movie.title, movie.director, ...((window.CineStorage ? window.CineStorage.normalizeCast(movie.cast) : []).map(function (c) { return c.name; })), ...genres, movie.language, movie.year, movie.synopsis]
      .join(" ").toLowerCase();
    return haystack.includes(query.toLowerCase());
  }

  function sorted(list) {
    return list.slice().sort((a, b) => {
      if (state.sort === "year") return (Number(b.year) || 0) - (Number(a.year) || 0);
      if (state.sort === "title") return String(a.title || "").localeCompare(String(b.title || ""));
      return (Number(b.rating) || 0) - (Number(a.rating) || 0);
    });
  }

  function escape(value) {
    if (window.CineUtils && typeof window.CineUtils.escapeHTML === "function") return window.CineUtils.escapeHTML(value);
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[c]));
  }

  function createCard(movie) {
    if (window.CineUtils && typeof window.CineUtils.createMovieCard === "function") return window.CineUtils.createMovieCard(movie);
    return `<article class="movie-card"><div class="movie-info"><a class="movie-title" href="./movie.html?id=${encodeURIComponent(movie.id)}">${escape(movie.title)}</a><div class="movie-meta">${escape(movie.year || "")}</div><span class="movie-genre">${escape((movie.genres || ["Movie"])[0])}</span></div></article>`;
  }

  function updateURL() {
    const p = new URLSearchParams();
    if (state.query) p.set("q", state.query);
    if (state.genre) p.set("genre", state.genre);
    if (state.sort !== "rating") p.set("sort", state.sort);
    history.replaceState({}, "", "search.html" + (p.toString() ? "?" + p.toString() : ""));
  }

  function renderChips() {
    const wrap = $("genreChips"); if (!wrap) return;
    // Clear existing chips before rendering, otherwise each genre click duplicates them.
    wrap.replaceChildren();
    const genres = Array.isArray(window.GENRE_DATA) ? window.GENRE_DATA : [];
    [{name:""}].concat(genres).forEach(g => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "genre-chip" + (state.genre === g.name ? " active" : "");
      b.dataset.genre = g.name; b.setAttribute("aria-pressed", String(state.genre === g.name));
      b.textContent = g.name || "All"; wrap.appendChild(b);
    });
  }

  function renderSuggestions(query) {
    const grid = $("searchResultsGrid"), count = $("resultCount");
    if (!grid) return;
    const all = getMovies();
    const results = sorted(all.filter(m => matches(m, query)));
    if (count) count.textContent = query ? `${results.length} matching movies` : `${results.length} movies available`;
    if (!results.length) {
      const alt = (query && window.CineSmart) ? window.CineSmart.didYouMean(query, all, 3) : [];
      const dym = alt.length
        ? `<div class="dym"><p>Did you mean:</p>${alt.map(m => `<button type="button" class="dym-btn" data-dym="${escape(m.title)}">${escape(m.title)}</button>`).join("")}</div>`
        : "";
      const req = query
        ? `<button type="button" class="primary-btn dym-req" data-dym-request="${escape(query)}"><i class="fa-solid fa-circle-plus"></i> Request "${escape(query)}"</button>`
        : "";
      grid.innerHTML = `<div class="empty-state"><i class="fa-solid fa-film"></i><h3>No movies found</h3><p>Try another title, actor, director or genre.</p>${dym}${req}</div>`;
      return;
    }
    grid.innerHTML = results.map(createCard).join("");
  }

  function bindDym() {
    const grid = $("searchResultsGrid");
    if (!grid || grid._dymBound) return;
    grid._dymBound = true;
    grid.addEventListener("click", function (e) {
      const d = e.target.closest("[data-dym]");
      const r = e.target.closest("[data-dym-request]");
      if (d) {
        const box = $("globalSearch");
        if (box) { box.value = d.dataset.dym; box.dispatchEvent(new Event("input", { bubbles: true })); }
        renderSuggestions(d.dataset.dym);
      }
      if (r && window.CineOpenRequest) window.CineOpenRequest(r.dataset.dymRequest);
    });
  }

  function start() {
    bindDym();
    const form = $("pageSearchForm"), input = $("pageSearch"), sort = $("sortSelect"), chips = $("genreChips");
    if (input) input.value = state.query;
    if (sort) sort.value = state.sort;
    renderChips();
    renderSuggestions(state.query);

    // Live search: update the movie list directly underneath the search bar as the user types.
    if (input) input.addEventListener("input", () => {
      state.query = input.value.trim(); updateURL(); renderSuggestions(state.query);
    });
    if (form && input) form.addEventListener("submit", e => {
      e.preventDefault(); state.query = input.value.trim(); updateURL(); renderSuggestions(state.query);
    });
    if (sort) sort.addEventListener("change", () => { state.sort = sort.value; updateURL(); renderSuggestions(state.query); });
    if (chips) chips.addEventListener("click", e => {
      const button = e.target.closest("[data-genre]"); if (!button) return;
      state.genre = button.dataset.genre || "";
      renderChips(); updateURL(); renderSuggestions(state.query);
    });
    if (window.CineUtils && window.CineUtils.setupHeader) window.CineUtils.setupHeader();
    if (window.CineUtils && window.CineUtils.setupWatchlistButtons) window.CineUtils.setupWatchlistButtons();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
