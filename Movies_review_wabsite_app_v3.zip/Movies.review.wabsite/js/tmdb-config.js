// TMDB key for actor pages (personal use). Images and data come from themoviedb.org.
window.CINE_TMDB = { apiKey: "f641d51cbd3f7ab90c4cf0fe32a887f4" };
