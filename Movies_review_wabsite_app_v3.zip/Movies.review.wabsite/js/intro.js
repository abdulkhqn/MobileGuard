(function () {
  "use strict";

  // Premium opening animation for the home page.
  // Plays once per browser session. The intro closes automatically.

  const html = document.documentElement;
  const screen = document.getElementById("introScreen");

  function finish() {
    html.classList.remove("intro-active");
    html.classList.add("site-ready");
    document.body.style.overflow = "";
    if (screen) screen.remove();
  }

  if (!screen || !html.classList.contains("intro-active")) {
    html.classList.add("site-ready");
    if (screen) screen.remove();
    return;
  }

  let done = false;
  const timers = [];

  function leave() {
    if (done) return;
    done = true;
    timers.forEach(window.clearTimeout);
    screen.classList.add("leaving");
    // reveal hero animation while the curtain is opening
    timers.push(window.setTimeout(function () { html.classList.add("site-ready"); }, 250));
    timers.push(window.setTimeout(finish, 1050));
  }

  document.body.style.overflow = "hidden";
  timers.push(window.setTimeout(leave, 3000));
  screen.addEventListener("click", leave);

  try { sessionStorage.setItem("cinereview_intro_seen", "1"); localStorage.setItem("cinereview_intro_seen_v3", "1"); } catch (e) {}
})();
