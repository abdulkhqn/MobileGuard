(function () {
  "use strict";

  // Live suggestions while typing in the search box.
  function start() {
  const input = document.getElementById("globalSearch");
  const form = document.getElementById("searchForm");
  if (!input || !form || !window.CineSmart) return;

  form.style.position = "relative";
  const drop = document.createElement("div");
  drop.className = "sg-drop";
  drop.hidden = true;
  form.appendChild(drop);

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function movies() { return window.CineStorage ? window.CineStorage.getMovies() : []; }

  function paint() {
    const q = input.value.trim();
    document.body.classList.toggle("is-searching", !!q);
    if (!q) { drop.hidden = true; drop.innerHTML = ""; return; }
    const list = window.CineSmart.suggestions(q, movies(), 6);
    if (!list.length) { drop.hidden = true; drop.innerHTML = ""; return; }
    drop.innerHTML = list.map(function (m, i) {
      const poster = m.poster ? '<img src="' + esc(m.poster) + '" alt="">' : '<span class="sg-noimg"><i class="fa-solid fa-film"></i></span>';
      return '<a class="sg-item" href="./movie.html?id=' + encodeURIComponent(m.id) + '" style="--i:' + i + '">' +
        poster + '<span><strong>' + esc(m.title) + '</strong><small>' + esc(m.year || "") + '</small></span></a>';
    }).join("");
    drop.hidden = false;
  }

  input.addEventListener("input", paint);
  input.addEventListener("focus", paint);
  document.addEventListener("click", function (e) {
    if (!form.contains(e.target)) drop.hidden = true;
  });
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
