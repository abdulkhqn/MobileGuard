# MobileGuard ProGuard rules (currently no custom rules).
