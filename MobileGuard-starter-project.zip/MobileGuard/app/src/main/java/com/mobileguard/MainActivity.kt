package com.mobileguard

import android.app.Activity
import android.app.AlertDialog
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.Gravity
import android.graphics.Color
import android.text.InputType
import android.widget.EditText

class MainActivity : Activity() {
    private val pickAudioCode = 41
    private var audioUri: Uri? = null
    private var player: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("mobileguard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(15, 18, 26))
        }
        fun label(text: String, size: Float = 18f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 14, 0, 14)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; setOnClickListener { action() }
        }
        layout.addView(label("MobileGuard", 30f))
        layout.addView(label("Offline audio utility — setup build"))
        layout.addView(button("RED Admin Panel") { adminLogin() })
        layout.addView(button("Select audio from phone") { selectAudio() })
        layout.addView(button("Preview / Stop audio") { previewAudio() })
        layout.addView(button("Start test alarm (repeat)") { startAlarm() })
        layout.addView(button("Stop alarm") { stopAlarm() })
        layout.addView(label("Camera/face recognition is not active in this starter build."))
        layout.addView(label("Monitoring must be clearly indicated and started by the phone owner."))
        setContentView(layout)
    }

    private fun adminLogin() {
        val input = EditText(this).apply {
            hint = "RED password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("RED Admin")
            .setView(input)
            .setPositiveButton("Unlock") { _, _ ->
                val saved = prefs.getString("admin_password", null)
                val entered = input.text.toString()
                if (saved == null) {
                    if (entered.length >= 6) {
                        prefs.edit().putString("admin_password", entered).apply()
                        Toast.makeText(this, "RED password created", Toast.LENGTH_LONG).show()
                    } else Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_LONG).show()
                } else if (entered == saved) {
                    AlertDialog.Builder(this).setTitle("RED Admin")
                        .setMessage("Admin unlocked. Use the home screen to select audio and test the alarm.")
                        .setPositiveButton("OK", null).show()
                } else Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun selectAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickAudioCode)
    }

    @Deprecated("Deprecated by Android API; kept for broad compatibility in this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickAudioCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            audioUri = uri
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("audio_uri", uri.toString()).apply()
            Toast.makeText(this, "Audio selected", Toast.LENGTH_SHORT).show()
        }
    }

    private fun currentUri(): Uri? = audioUri ?: prefs.getString("audio_uri", null)?.let { Uri.parse(it) }

    private fun previewAudio() {
        stopAlarm()
        val uri = currentUri()
        if (uri == null) {
            Toast.makeText(this, "Pehle audio select karo", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnCompletionListener { it.release(); player = null }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Audio play nahi hua: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun startAlarm() {
        stopAlarm()
        val uri = currentUri()
        if (uri == null) {
            Toast.makeText(this, "Pehle audio select karo", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Audio play nahi hua: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopAlarm() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    override fun onDestroy() {
        stopAlarm()
        super.onDestroy()
    }
}
