# MobileGuard

This is the first buildable starter stage for MobileGuard.

Included now:
- Android app shell
- RED admin password setup/unlock
- Choose an audio file from device storage
- Preview selected audio
- Repeat/stop test alarm
- GitHub Actions workflow to build a debug APK

Not included yet:
- Face enrollment or face identity matching
- Camera monitoring service
- Lock-screen monitoring

Those features require a tested on-device face-embedding model and a user-visible Android camera foreground service. This starter deliberately does not claim to recognize faces or run a hidden camera.

## Build
Push the repository to GitHub. Open Actions, choose "Build MobileGuard APK" if needed, and run the workflow. Download the `MobileGuard-debug-apk` artifact from the completed run.

Target SDK is 35 for broad compatibility with Android 16 devices; the app itself uses standard Android APIs and does not include native ABI-specific libraries.
